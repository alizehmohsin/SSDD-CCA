from fastapi.testclient import TestClient
from datetime import datetime, timedelta, timezone
from fixed_version.app import app, encode_token

client = TestClient(app)
OTHER_DOCTOR_RX = 'd963d5a7-90a8-4be6-9aab-222222222222'


def auth_header(username='dr_smith', password='pass123'):
    token = client.post('/login', json={'username': username, 'password': password}).json()['access_token']
    return {'Authorization': f'Bearer {token}'}


def test_secure_prescription_access_should_block_other_doctor_data():
    headers = auth_header('dr_smith')
    response = client.get(f'/prescriptions/{OTHER_DOCTOR_RX}', headers=headers)
    assert response.status_code in (403, 404)


def test_video_token_should_not_be_reusable():
    headers = auth_header('dr_smith')
    session_response = client.get('/video/session/apt-1001', headers=headers)
    session_token = session_response.json()['session_token']
    first = client.get('/video/join', params={'token': session_token}, headers=headers)
    second = client.get('/video/join', params={'token': session_token}, headers=headers)
    assert first.status_code == 200
    assert second.status_code == 403


def test_expired_jwt_should_be_rejected():
    expired = encode_token({'sub': 'dr_smith', 'exp': int((datetime.now(timezone.utc) - timedelta(minutes=5)).timestamp())})
    response = client.get('/profile', headers={'Authorization': f'Bearer {expired}'})
    assert response.status_code == 401
