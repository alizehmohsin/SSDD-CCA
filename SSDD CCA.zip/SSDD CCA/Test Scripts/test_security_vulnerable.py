from fastapi.testclient import TestClient
from datetime import datetime, timedelta, timezone
from vulnerable_version.app import app, encode_token

client = TestClient(app)


def auth_header(username='dr_smith', password='pass123'):
    token = client.post('/login', json={'username': username, 'password': password}).json()['access_token']
    return {'Authorization': f'Bearer {token}'}


def test_secure_prescription_access_should_block_other_doctor_data():
    headers = auth_header('dr_smith')
    response = client.get('/prescriptions/102', headers=headers)
    assert response.status_code in (403, 404)


def test_video_token_should_not_be_reusable():
    headers = auth_header('dr_smith')
    session_response = client.get('/video/session/apt-1001', headers=headers)
    join_link = session_response.json()['join_link']
    first = client.get('/video/join', params={'link': join_link})
    second = client.get('/video/join', params={'link': join_link})
    assert first.status_code == 200
    assert second.status_code == 403


def test_expired_jwt_should_be_rejected():
    expired = encode_token({'sub': 'dr_smith', 'exp': int((datetime.now(timezone.utc) - timedelta(minutes=5)).timestamp())})
    response = client.get('/profile', headers={'Authorization': f'Bearer {expired}'})
    assert response.status_code == 401
