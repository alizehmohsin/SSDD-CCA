# MediSafe CCA - Secure Software Design & Development

This project is a complete **Complex Computing Activity (CCA)** submission for **CT-477 Secure Software Design & Development**. It uses the same **MediSafe Telemedicine Platform** concept from the CCP and demonstrates three intentional vulnerabilities in a vulnerable version, followed by a secure fixed version.

## CCA Requirements Covered
- Working software application
- At least three distinct security vulnerabilities intentionally added
- Vulnerable version
- Fixed version
- Automated tests
- Demo video script support

## Vulnerabilities Included
1. **IDOR in prescription access**
2. **Insecure video session link sharing / reuse**
3. **JWT token leakage and expired-token acceptance**

## Project Structure
```text
medisafe_cca/
├── vulnerable_version/
│   └── app.py
├── fixed_version/
│   └── app.py
├── tests/
│   ├── test_security_vulnerable.py
│   └── test_security_fixed.py
├── docs/
│   └── CCA_Report.md
├── requirements.txt
└── README.md
```

## How to Run
```bash
pip install -r requirements.txt
uvicorn vulnerable_version.app:app --reload
uvicorn fixed_version.app:app --reload --port 8001
```

## How to Run Tests
### Vulnerable version
These tests represent **secure expectations**, so they are expected to fail against the vulnerable app:
```bash
pytest tests/test_security_vulnerable.py
```

### Fixed version
These same secure expectations should pass against the fixed app:
```bash
pytest tests/test_security_fixed.py
```

## Demo Flow
1. Log in as `dr_smith / pass123`
2. On vulnerable version, access prescription `102` and show unauthorized access works
3. On vulnerable version, get raw video join link and use it multiple times
4. On vulnerable version, send an expired JWT to `/profile` and show it is still accepted
5. Repeat on fixed version and show each case is blocked

## Notes
- This is a minimal academic demonstration project, not a production healthcare platform.
- The vulnerable version intentionally contains unsafe patterns for learning purposes.
