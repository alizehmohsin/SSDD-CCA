from fastapi import FastAPI, HTTPException, Header, Query
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timedelta, timezone
import json, base64, hmac, hashlib, uuid

app = FastAPI(title='MediSafe Fixed')

SECRET_KEY = 'medisafe-demo-secret'
ALGORITHM = 'HS256'

USERS = {
    'dr_smith': {'password': 'pass123', 'role': 'doctor', 'doctor_id': 'doc-1'},
    'dr_jones': {'password': 'pass123', 'role': 'doctor', 'doctor_id': 'doc-2'},
    'patient_ali': {'password': 'pass123', 'role': 'patient', 'patient_id': 'pat-1'},
}

PRESCRIPTIONS = {
    '7ec6d239-5f1d-4c85-9cf8-111111111111': {'doctor_id': 'doc-1', 'patient_id': 'pat-1', 'medicine': 'Paracetamol', 'notes': 'Take twice daily'},
    'd963d5a7-90a8-4be6-9aab-222222222222': {'doctor_id': 'doc-2', 'patient_id': 'pat-2', 'medicine': 'Amoxicillin', 'notes': 'Take after meals'},
}

APPOINTMENTS = {'apt-1001': 'doc-1'}
SESSION_TOKENS = {}

class LoginRequest(BaseModel):
    username: str
    password: str


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip('=')


def _b64decode(data: str) -> bytes:
    padding = '=' * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def encode_token(payload: dict) -> str:
    header = {'alg': ALGORITHM, 'typ': 'JWT'}
    h = _b64(json.dumps(header, separators=(',', ':')).encode())
    p = _b64(json.dumps(payload, separators=(',', ':')).encode())
    sig = hmac.new(SECRET_KEY.encode(), f'{h}.{p}'.encode(), hashlib.sha256).digest()
    return f'{h}.{p}.{_b64(sig)}'


def decode_token(token: str, verify_exp: bool = True) -> dict:
    try:
        h, p, s = token.split('.')
        expected = _b64(hmac.new(SECRET_KEY.encode(), f'{h}.{p}'.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(expected, s):
            raise ValueError('bad signature')
        payload = json.loads(_b64decode(p).decode())
        if verify_exp and payload.get('exp', 0) < int(datetime.now(timezone.utc).timestamp()):
            raise ValueError('expired')
        return payload
    except Exception:
        raise HTTPException(status_code=401, detail='Invalid or expired token')


def create_token(username: str, minutes: int = 10) -> str:
    payload = {
        'sub': username,
        'exp': int((datetime.now(timezone.utc) + timedelta(minutes=minutes)).timestamp())
    }
    return encode_token(payload)


def get_current_user(authorization: Optional[str]):
    if not authorization or not authorization.startswith('Bearer '):
        raise HTTPException(status_code=401, detail='Missing token')
    token = authorization.split(' ', 1)[1]
    payload = decode_token(token, verify_exp=True)
    username = payload['sub']
    return username, USERS[username]


@app.get('/')
def root():
    return {'app': 'MediSafe Fixed'}


@app.post('/login')
def login(body: LoginRequest):
    user = USERS.get(body.username)
    if not user or user['password'] != body.password:
        raise HTTPException(status_code=401, detail='Invalid credentials')
    return {'access_token': create_token(body.username)}


@app.get('/profile')
def profile(authorization: Optional[str] = Header(default=None)):
    _, user = get_current_user(authorization)
    return {'role': user['role'], 'message': 'Token accepted'}


@app.get('/prescriptions/{prescription_id}')
def get_prescription(prescription_id: str, authorization: Optional[str] = Header(default=None)):
    _, user = get_current_user(authorization)
    if user['role'] != 'doctor':
        raise HTTPException(status_code=403, detail='Doctors only')

    try:
        uuid.UUID(prescription_id)
    except Exception:
        raise HTTPException(status_code=404, detail='Not found')

    item = PRESCRIPTIONS.get(prescription_id)
    if not item:
        raise HTTPException(status_code=404, detail='Not found')

    if item['doctor_id'] != user['doctor_id']:
        raise HTTPException(status_code=404, detail='Not found')
    return item


@app.get('/video/session/{appointment_id}')
def get_video_session(appointment_id: str, authorization: Optional[str] = Header(default=None)):
    username, user = get_current_user(authorization)
    if appointment_id not in APPOINTMENTS:
        raise HTTPException(status_code=404, detail='Unknown appointment')
    if user['role'] != 'doctor' or APPOINTMENTS[appointment_id] != user['doctor_id']:
        raise HTTPException(status_code=403, detail='Not authorized for appointment')

    token = str(uuid.uuid4())
    SESSION_TOKENS[token] = {
        'user': username,
        'appointment_id': appointment_id,
        'exp': datetime.now(timezone.utc) + timedelta(minutes=2),
        'used': False,
    }
    return {'session_token': token}


@app.get('/video/join')
def join_video(token: str = Query(...), authorization: Optional[str] = Header(default=None)):
    username, _ = get_current_user(authorization)
    session = SESSION_TOKENS.get(token)
    if not session:
        raise HTTPException(status_code=404, detail='Unknown token')
    if session['used']:
        raise HTTPException(status_code=403, detail='Token already used')
    if session['user'] != username:
        raise HTTPException(status_code=403, detail='Token not issued for this user')
    if session['exp'] < datetime.now(timezone.utc):
        raise HTTPException(status_code=401, detail='Session token expired')

    session['used'] = True
    return {'status': 'joined', 'appointment_id': session['appointment_id']}
