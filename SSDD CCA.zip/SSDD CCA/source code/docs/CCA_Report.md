# Complex Computing Activity (CCA)
## Secure Implementation of MediSafe Telemedicine Platform

### 1. Introduction
MediSafe is a telemedicine platform developed to support secure interaction between patients and doctors. It enables remote consultations, prescription management, and secure session handling. For this CCA, two versions of the application were developed: a vulnerable version containing intentional security flaws, and a fixed version where those vulnerabilities were removed.

### 2. Objective
The objective of this activity is to demonstrate secure software design and development by building a working software application, intentionally introducing security vulnerabilities, fixing them, and proving the fixes through automated testing.

### 3. System Description
The MediSafe application is implemented as a lightweight REST API. The system supports authentication, prescription access for doctors, and video consultation session handling. The project focuses on practical security weaknesses commonly found in web applications.

### 4. Vulnerable Version
The first version of the system intentionally includes three security flaws.

#### 4.1 Vulnerability 1: Insecure Direct Object Reference (IDOR)
The prescription endpoint uses direct identifiers and validates only that the requester is a doctor. It does not verify whether the requesting doctor owns the prescription. As a result, one doctor can access another doctor’s patient data.

#### 4.2 Vulnerability 2: Insecure Video Session Handling
The video consultation endpoint returns a raw reusable join link. Anyone who obtains the link can use it repeatedly to join or simulate joining the session.

#### 4.3 Vulnerability 3: JWT Token Leakage / Insecure Token Validation
The vulnerable version logs JWTs and disables expiration verification. This means an expired token can still be used to access protected endpoints.

### 5. Fixed Version
The fixed implementation eliminates the above issues using secure design principles.

#### 5.1 Fix for IDOR
Sequential-style direct access is replaced with UUID-based resource access. More importantly, ownership verification is performed before returning prescription data. Unauthorized access is denied.

#### 5.2 Fix for Video Session Security
Instead of exposing raw join links, the system generates short-lived one-time session tokens bound to the authenticated user. Reuse of the token is blocked.

#### 5.3 Fix for JWT Token Handling
JWTs are no longer logged. Expiration validation is enforced, and expired tokens are rejected.

### 6. Automated Testing
Three automated security tests were written.

- **IDOR test**: secure expectation is that one doctor must not access another doctor’s prescription.
- **Video session reuse test**: secure expectation is that a session token or session entry must not be reusable.
- **Expired JWT test**: secure expectation is that expired tokens must be rejected.

These tests fail on the vulnerable version and pass on the fixed version.

### 7. Deliverables
This submission includes the vulnerable application, fixed application, automated tests, repository documentation, and a demo-ready report.

### 8. Conclusion
This project demonstrates how realistic web security flaws can be intentionally introduced and then corrected through secure design. By applying object-level authorization, one-time session tokens, and strict JWT validation, the MediSafe platform becomes significantly more secure. The activity shows that security must be integrated into implementation and testing, not only documented in design reports.
