# Demo Video Script (4-5 minutes)

## Intro
Hello, this is our CT-477 Complex Computing Activity project called MediSafe. We created two versions of the same telemedicine platform: a vulnerable version and a fixed version.

## Attack 1 - IDOR
First, I log in as Dr. Smith. In the vulnerable version, if I call the prescription endpoint with ID 102, I can access another doctor’s prescription even though it does not belong to me. This demonstrates an insecure direct object reference.

Now in the fixed version, the same kind of unauthorized access is blocked because the application verifies doctor ownership before returning the prescription.

## Attack 2 - Video Session Reuse
In the vulnerable version, the application returns a raw video join link. That link can be used again and again by anyone who has it. This creates a privacy risk for telemedicine consultations.

In the fixed version, the system returns a short-lived one-time session token. The first use succeeds, but the second use is rejected.

## Attack 3 - Expired JWT Acceptance
In the vulnerable version, JWT expiration is not properly enforced. Even an expired token is still accepted by the profile endpoint.

In the fixed version, the same expired token is rejected, which prevents replay or reuse of old credentials.

## Closing
This project demonstrates secure software design and development by building a working application, intentionally adding vulnerabilities, fixing them, and proving the fixes with automated tests.
