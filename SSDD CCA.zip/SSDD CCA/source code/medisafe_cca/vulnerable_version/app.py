from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timedelta, timezone
import json, base64, hmac, hashlib

app = FastAPI(title='MediSafe Vulnerable')

SECRET_KEY = 'medisafe-demo-secret'
ALGORITHM = 'HS256'

USERS = {
    'dr_smith': {'password': 'pass123', 'role': 'doctor', 'doctor_id': 'doc-1'},
    'dr_jones': {'password': 'pass123', 'role': 'doctor', 'doctor_id': 'doc-2'},
    'patient_ali': {'password': 'pass123', 'role': 'patient', 'patient_id': 'pat-1'},
}

PRESCRIPTIONS = {
    101: {'doctor_id': 'doc-1', 'patient_id': 'pat-1', 'medicine': 'Paracetamol', 'notes': 'Take twice daily'},
    102: {'doctor_id': 'doc-2', 'patient_id': 'pat-2', 'medicine': 'Amoxicillin', 'notes': 'Take after meals'},
}

VIDEO_LINKS = {
    'apt-1001': 'https://video.medisafe.local/session/apt-1001-open-link'
}

class LoginRequest(BaseModel):
    username: str
    password: str


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip('=')


def _b64decode(data: str) -> bytes:
    padding = '=' * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def encode_token(payload: dict) -> str:
    header = {'alg': ALGORITHM, 'typ': 'JWT'}
    h = _b64(json.dumps(header, separators=(',', ':')).encode())
    p = _b64(json.dumps(payload, separators=(',', ':')).encode())
    sig = hmac.new(SECRET_KEY.encode(), f'{h}.{p}'.encode(), hashlib.sha256).digest()
    return f'{h}.{p}.{_b64(sig)}'


def decode_token(token: str, verify_exp: bool = True) -> dict:
    try:
        h, p, s = token.split('.')
        expected = _b64(hmac.new(SECRET_KEY.encode(), f'{h}.{p}'.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(expected, s):
            raise ValueError('bad signature')
        payload = json.loads(_b64decode(p).decode())
        if verify_exp and payload.get('exp', 0) < int(datetime.now(timezone.utc).timestamp()):
            raise ValueError('expired')
        return payload
    except Exception:
        raise HTTPException(status_code=401, detail='Invalid token')


def create_token(username: str) -> str:
    payload = {
        'sub': username,
        'exp': int((datetime.now(timezone.utc) + timedelta(minutes=30)).timestamp())
    }
    token = encode_token(payload)
    with open('vulnerable_token.log', 'a', encoding='utf-8') as f:
        f.write(f'LOGIN TOKEN for {username}: {token}\n')
    return token


def get_current_user(authorization: Optional[str]):
    if not authorization or not authorization.startswith('Bearer '):
        raise HTTPException(status_code=401, detail='Missing token')
    token = authorization.split(' ', 1)[1]
    with open('vulnerable_token.log', 'a', encoding='utf-8') as f:
        f.write(f'REQUEST TOKEN: {token}\n')
    payload = decode_token(token, verify_exp=False)  # vulnerability
    username = payload['sub']
    return USERS[username]


@app.get('/')
def root():
    return {'app': 'MediSafe Vulnerable'}


@app.post('/login')
def login(body: LoginRequest):
    user = USERS.get(body.username)
    if not user or user['password'] != body.password:
        raise HTTPException(status_code=401, detail='Invalid credentials')
    return {'access_token': create_token(body.username)}


@app.get('/profile')
def profile(authorization: Optional[str] = Header(default=None)):
    user = get_current_user(authorization)
    return {'role': user['role'], 'message': 'Token accepted'}


@app.get('/prescriptions/{prescription_id}')
def get_prescription(prescription_id: int, authorization: Optional[str] = Header(default=None)):
    user = get_current_user(authorization)
    if user['role'] != 'doctor':
        raise HTTPException(status_code=403, detail='Doctors only')
    item = PRESCRIPTIONS.get(prescription_id)
    if not item:
        raise HTTPException(status_code=404, detail='Not found')
    return item


@app.get('/video/session/{appointment_id}')
def get_video_session(appointment_id: str, authorization: Optional[str] = Header(default=None)):
    get_current_user(authorization)
    if appointment_id not in VIDEO_LINKS:
        raise HTTPException(status_code=404, detail='Unknown appointment')
    return {'join_link': VIDEO_LINKS[appointment_id]}


@app.get('/video/join')
def join_video(link: str):
    if link not in VIDEO_LINKS.values():
        raise HTTPException(status_code=404, detail='Unknown link')
    return {'status': 'joined', 'link': link}
